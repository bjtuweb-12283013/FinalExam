<?php
$str_footer = 
'
<div id="footer"> 
	<div class="wrap clearfix">
		<div class="section f">
	    	<a id="logo1"><img src="images/footerlogo.png"></a>
	    </div>
	    <div class="section b">
	        <div class="border">
                <h3>关于我们</h3>
                <p>计算机与信息技术学院本科生党支部</p>
				<a href="admin/index.php">分级管理后台</a>
             </div><!--footer_main-->
	    </div>
	    <div class="section l">
			<div id="links">
				<h3>友情链接</h3>
				<p>
                    <a href="http://bjtu.edu.cn/" target="_blank">北京交通大学</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                    <a href="http://scit.bjtu.edu.cn/" target="_blank">计算机学院</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                    <a href="http://mail.bjtu.edu.cn/" target="_blank">交大邮箱</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                    <a href="http://jwc.bjtu.edu.cn/" target="_blank">教务处</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                    <a href="http://ic.njtu.edu.cn/" target="_blank">信息中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                    <a href="http://lib.njtu.edu.cn/" target="_blank">图书馆</a>
                </p><!--footer_main_fans-->
			</div>
		</div>  
	</div>
    <div class="footer_bottom">
        <div>
            <a href="#" target="_blank">关于我们</a> | 
            <a href="#" target="_blank">联系我们</a> | 
            <a href="#" target="_blank">版权声明</a> | 
            <a href="#" target="_blank">诚聘英才</a> | 
            <a href="#" target="_blank">杂志订阅</a>
        </div>
    
        <div>
            <a href="#" target="_blank">Copyright 2014 BJTU_CIT All rights reserved</a> 
            <a href="#" target="_blank">暂未备案</a>
        </div>
    </div>
</div>   
';
echo $str_footer;
?>